class Deck
{
	ArrayList<Card> cards;
	public Deck(int n) {
		
	}
}