class Card
{
	String face, suit;
	public Card(String fName, String sName) {
		face = fName;
		suit = sName;
	}
}