class Dealer extends Partitioner
{
		public Dealer(String pName) {
		super(pName);
	}
}