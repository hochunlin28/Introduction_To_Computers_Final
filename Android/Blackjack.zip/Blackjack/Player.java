class Player extends Partitioner
{
	public Player(String pName) {
		super(pName);
	}
}